﻿# iconfont

SVG生成字体包，并生成css 样式引用

## 技术栈

gulp-iconfont + gulp-iconfont-css + gulp-template


## 项目运行 运行目录  /view/coreIcon/ 
安装node
npm install 
gulp 

## 项目使用
将新的svg图片放入src/core/icons/ 下
命令行输入gulp  
等待gulp执行完毕
在build/core/下
css目录下是我们所需的iconfont.css 文件，
fonts是我们的字体文件，将字体文件和css文件放入core/view 下 注意路径

只需要将这个iconfont.css引入页面即可
example目录下的index是图标示例，可以来这里看图标对应的class

祝你工作愉快  (*@ο@*) 哇～